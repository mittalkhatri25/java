package jdbc;

import java.sql.Statement;

public class connection {

	public Statement createstatement() {
		// TODO Auto-generated method stub
		return null;
	}

}
