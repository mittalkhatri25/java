public class BankApp {
    public static void main(String[] args) {
        BankFactory factory = new MMBankFactory();

        SavingAcc savingAcc = factory.getNewSavingAcc(1, "Rahul pandey", 100.0f, true);
        CurrentAcc currentAcc = factory.getNewCurrentAcc(2, "Ravi pandey", 2000.0f, 500.0f);

        System.out.println(savingAcc);
        savingAcc.withdraw(600);
        System.out.println(savingAcc);

        System.out.println(currentAcc);
        currentAcc.withdraw(2300);
        System.out.println(currentAcc);
    }
}
